export interface TextValue {
        text: string;
        gender?: string;     // e.g., "Male"
        plural?: string;     // e.g., "0:1"
}